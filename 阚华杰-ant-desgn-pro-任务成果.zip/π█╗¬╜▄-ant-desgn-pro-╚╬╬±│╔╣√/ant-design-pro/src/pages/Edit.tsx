import {
  Badge,
  Button,
  Card,
  Col,
  DatePicker,
  Divider,
  Dropdown,
  Form,
  Icon,
  Input,
  Menu,
  Row,
  Select,
  message,
} from 'antd';
import React, { Component, Fragment, } from 'react';
import { Dispatch } from 'redux';
import { FormComponentProps } from 'antd/es/form';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { SorterResult } from 'antd/es/table';
import { connect } from 'dva';
import moment from 'moment';
import { StateType } from '@/models/model';
import CreateForm from '@/components/CreateForm';
import StandardTable, { StandardTableColumnProps } from '@/components/StandardTable';
import UpdateForm, { FormValsType } from '@/components/UpdateForm';
import { TableListItem, TableListPagination, TableListParams } from '@/data.d';
import styles from '@/style.less';
import * as XLSX from 'xlsx';
const FormItem = Form.Item;
const { Option } = Select;
const getValue = (obj: { [x: string]: string[] }) =>
  Object.keys(obj)
    .map(key => obj[key])
    .join(',');

// 状态status值两种
type IStatusMapType = | 'success' | 'error';
const statusMap = [ 'success', 'error'];
const status = ['已完成', '未完成'];

interface TableListProps extends FormComponentProps {
  dispatch: Dispatch<any>;
  loading: boolean;
  BLOCK_NAME_CAMEL_CASE: StateType;
}

interface TableListState {
  modalVisible: boolean;
  updateModalVisible: boolean;
  expandForm: boolean;
  selectedRows: TableListItem[];
  formValues: { [key: string]: string };
  stepFormValues: Partial<TableListItem>;
}

@connect(
  ({
    BLOCK_NAME_CAMEL_CASE,
    loading,
  }: {
    BLOCK_NAME_CAMEL_CASE: StateType;
    loading: {
      models: {
        [key: string]: boolean;
      };
    };
  }) => ({
    BLOCK_NAME_CAMEL_CASE,
    loading: loading.models.rule,
  }),
)
class TableList extends Component<TableListProps, TableListState> {
  state: TableListState = {
    modalVisible: false,
    updateModalVisible: false,
    expandForm: false,
    selectedRows: [],
    formValues: {},
    stepFormValues: {},
  };
  
  //列表标题
  columns: StandardTableColumnProps[] = [
    {
      title: '姓名',
      dataIndex: 'name',
    },
    {
      title: '工作描述',
      dataIndex: 'desc',
    },
    {
      title: '开始时间',
      dataIndex: 'createdAt',
      sorter: true,
      render: (val: string) => <span>{moment(val).format('YYYY-MM-DD')}</span>,
    },
    {
      title: '完成时间',
      dataIndex: 'updatedAt',
      //sorter: true,
      render: (val: string) => <span>{moment(val).format('YYYY-MM-DD')}</span>,
    },
    {
      title: '状态',
      dataIndex: 'status',
      filters: [
        {
          text: status[0],
          value: '0',
        },
        {
          text: status[1],
          value: '1',
        },
      ],
      render(val: IStatusMapType) {
        return <Badge status={statusMap[val]} text={status[val]} />;
      },
    },
    {
      title: '操作',
      render: (text, record) => (
        <Fragment>
          <a onClick={() => this.handleUpdateModalVisible(true, record)}>修改</a>
          <Divider type="vertical" />
          
        </Fragment>
      ),
    },
  ];

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'BLOCK_NAME_CAMEL_CASE/fetch',
    });
  }

  handleStandardTableChange = (
    pagination: Partial<TableListPagination>,
    filtersArg: Record<keyof TableListItem, string[]>,
    sorter: SorterResult<TableListItem>,
  ) => {
    const { dispatch } = this.props;
    const { formValues } = this.state;

    const filters = Object.keys(filtersArg).reduce((obj, key) => {
      const newObj = { ...obj };
      newObj[key] = getValue(filtersArg[key]);
      return newObj;
    }, {});

    const params: Partial<TableListParams> = {
      currentPage: pagination.current,
      pageSize: pagination.pageSize,
      ...formValues,
      ...filters,
    };
    if (sorter.field) {
      params.sorter = `${sorter.field}_${sorter.order}`;
    }

    dispatch({
      type: 'BLOCK_NAME_CAMEL_CASE/fetch',
      payload: params,
    });
  };
  
  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    this.setState({
      formValues: {},
    });
    dispatch({
      type: 'BLOCK_NAME_CAMEL_CASE/fetch',
      payload: {},
    });
  };

  toggleForm = () => {
    const { expandForm } = this.state;
    this.setState({
      expandForm: !expandForm,
    });
  };

  handleMenuClick = (e: { key: string }) => {
    const { dispatch } = this.props;
    const { selectedRows } = this.state;

    if (!selectedRows) return;
    switch (e.key) {
      case 'remove':
        dispatch({
          type: 'BLOCK_NAME_CAMEL_CASE/remove',
          payload: {
            key: selectedRows.map(row => row.key),
          },
          callback: () => {
            this.setState({
              selectedRows: [],
            });
          },
        });
        break;
      default:
        break;
    }
  };
  
  // 多行选择
  handleSelectRows = (rows: TableListItem[]) => {
    this.setState({
      selectedRows: rows,
    });
  };
  //查询功能
  handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      const values = {
        ...fieldsValue,
      //updatedAt: fieldsValue.updatedAt && fieldsValue.updatedAt.valueOf(),
      };
      this.setState({
        formValues: values,
      });
      dispatch({
        type: 'BLOCK_NAME_CAMEL_CASE/fetch',
        payload: values,
      });
    });
  };

  handleModalVisible = (flag?: boolean) => {
    this.setState({
      modalVisible: !!flag,
    });
  };

  handleUpdateModalVisible = (flag?: boolean, record?: FormValsType) => {
    this.setState({
      updateModalVisible: !!flag,
      stepFormValues: record || {},
    });
  };
  //新增功能
  handleAdd = (fields: { desc: any; name: any; status: any; createdAt: any; updatedAt: any; }) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'BLOCK_NAME_CAMEL_CASE/add',
      payload: {
        // 传递值
        desc: fields.desc,
        name:fields.name,
        status:fields.status,
        createdAt:fields.createdAt,
        updatedAt:fields.updatedAt,
      },
    });

    message.success('添加成功');
    this.handleModalVisible();
  };
  //修改功能
  handleUpdate = (fields: FormValsType) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'BLOCK_NAME_CAMEL_CASE/update',
      payload: {
        name: fields.name, // 姓名
        desc: fields.desc,// 工作描述
        status:fields.status,// 添加状态
        updatedAt:fields.updatedAt,// 添加完成时间
        createdAt:fields.createdAt,// 添加创建时间
        key: fields.key,
      },
    });
    message.success('修改成功');
    this.handleUpdateModalVisible();
  };
  
  //导出excel
  downloadExcel = () => {
    const ExportJsonExcel = require('js-export-excel');
    // 将浏览器上的列表数据压入数组
    const { BLOCK_NAME_CAMEL_CASE: {data} } = this.props;//列表数据
    let dataTable = [];//数组
    if (data) {
       for (let i in data.list) {
         if(data.list){
           let obj = {
             '姓名': data.list[i].name,
             '工作描述': data.list[i].desc,
             '开始时间': moment(data.list[i].createdAt).format('YYYY-MM-DD'),
             '完成时间': moment(data.list[i].updatedAt).format('YYYY-MM-DD'),
             '状态': status[data.list[i].status],
            }
         dataTable.push(obj);
        }
      }
   }
    // excel表格对象
    var option={};
    option.fileName = '工作记录'
    option.datas=[
    {
      sheetData:dataTable,
      sheetName:'sheet00',
      sheetFilter:['姓名','工作描述','开始时间','完成时间','状态'],
      sheetHeader:['姓名','工作描述','开始时间','完成时间','状态'],
    }
   ];

    var toExcel = new ExportJsonExcel(option);
    toExcel.saveExcel();
  }

  //导入excel
  importExcel = (file: { target: { files: any; }; }) => {
      // 获取上传的文件对象
      const { files } = file.target;
      // 通过FileReader对象读取文件
      const fileReader = new FileReader();
      fileReader.onload = event => {
        try {
          const { result } = event.target;
          // 以二进制流方式读取得到整份excel表格对象
          const workbook = XLSX.read(result, { type: 'binary' });
          let data: any[] | never[] = []; // 存储获取到的数据
          // 遍历每张工作表进行读取（这里默认只读取第一张表）
          for (const sheet in workbook.Sheets) {
            if (workbook.Sheets.hasOwnProperty(sheet)) {
              // 利用 sheet_to_json 方法将 excel 转成 json 数据
              data = data.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
              break; // 如果只取第一张表，就取消注释这行
            }
          }
          message.success('上传成功！')
          console.log("data"+data);

          let dataTable = [];//数组
  
       for (let i in data) {
         if(data){
           let obj = {
             'name': data[i].姓名,
             'desc': data[i].工作描述,
             'createdAt': moment(data[i].开始时间).format('YYYY-MM-DD'),
             'updatedAt': moment(data[i].完成时间).format('YYYY-MM-DD'),
             'status': data[i].状态,
            };
         dataTable.push(obj);
         console.log("obj"+obj);
        }
        console.log(dataTable[0].status);
      }
          const { dispatch } = this.props;
          const m = new Map([
            ['已完成', 0],
            ['未完成', 1]
          ]);

          for (let i in dataTable) {
            if(dataTable){
           dispatch({
            type: 'BLOCK_NAME_CAMEL_CASE/add',
            payload:{
              name: dataTable[i].name,
              desc: dataTable[i].desc,
              createdAt: dataTable[i].createdAt,
              updatedAt: dataTable[i].updatedAt,
              status: m.get(dataTable[i].status),
            },
          });}}
        } catch (e) {
          // 这里可以抛出文件类型错误不正确的相关提示
          console.log('文件类型不正确');
          return;
        }
      };
      // 以二进制方式打开文件
      fileReader.readAsBinaryString(files[0]);
  }

  // 头部功能标题显示
  renderSimpleForm() {
    const { form } = this.props;
    const { getFieldDecorator } = form;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="姓名">
              {getFieldDecorator('name')(<Input placeholder="请输入姓名" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择状态" style={{ width: '100%' }}>
                  <Option value="0">已完成</Option>
                  <Option value="1">未完成</Option>
                </Select>
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <span className={styles.submitButtons}>
              <Button type="primary" htmlType="submit">
                查询
              </Button>
              <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
                重置
              </Button>
              <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
                展开 <Icon type="down" />
              </a>
            </span>
          </Col>
        </Row>
      </Form>
    );
  }

  renderAdvancedForm() {
    const {
      form: { getFieldDecorator },
    } = this.props;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="姓名">
              {getFieldDecorator('name')(<Input placeholder="请输入姓名" />)}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label="完成状态">
              {getFieldDecorator('status')(
                <Select placeholder="请选择状态" style={{ width: '100%' }}>
                  <Option value="0">已完成</Option>
                  <Option value="1">未完成</Option>
                </Select>,
              )}
            </FormItem>
          </Col>
        </Row>
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label="完成日期">
              {getFieldDecorator('updatedAt')(
                <DatePicker 
                style={{ width: '100%' }} 
                placeholder="请输入完成日期"
                format="YYYY-MM-DD"/>,
              )}
            </FormItem>
          </Col>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <Button type="primary" onClick={this.downloadExcel}>导出</Button>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <Button>
             <input type='file' accept='.xlsx, .xls' onChange={this.importExcel}/>
             </Button>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <div style={{ float: 'right', marginBottom: 24 }}>
            <Button type="primary" htmlType="submit">
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset}>
              重置
            </Button>
            <a style={{ marginLeft: 8 }} onClick={this.toggleForm}>
              收起 <Icon type="up" />
            </a>
          </div>
        </div>
      </Form>
    );
  }

  renderForm() {
    const { expandForm } = this.state;
    return expandForm ? this.renderAdvancedForm() : this.renderSimpleForm();
  }

  render() {
    const {
      BLOCK_NAME_CAMEL_CASE: { data },
      loading,
    } = this.props;

    const { selectedRows, modalVisible, updateModalVisible, stepFormValues } = this.state;
    const menu = (
      <Menu onClick={this.handleMenuClick} selectedKeys={[]}>
        <Menu.Item key="remove">删除</Menu.Item>
      </Menu>
        
    );

    const parentMethods = {
      handleAdd: this.handleAdd,
      handleModalVisible: this.handleModalVisible,
    };
    const updateMethods = {
      handleUpdateModalVisible: this.handleUpdateModalVisible,
      handleUpdate: this.handleUpdate,
    };
    return (
      <PageHeaderWrapper>
        <Card bordered={false}>
          <div className={styles.tableList}>
            <div className={styles.tableListForm}>{this.renderForm()}</div>
            <div className={styles.tableListOperator}>
              <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
                新增
              </Button>
              {selectedRows.length > 0 && (
                <span>
                  <Dropdown overlay={menu}>
                    <Button>
                      更多操作 <Icon type="down" />
                    </Button>
                  </Dropdown>
                </span>
              )}
            </div>
            <StandardTable
              selectedRows={selectedRows}
              loading={loading}
              data={data}
              columns={this.columns}
              onSelectRow={this.handleSelectRows}
              onChange={this.handleStandardTableChange}
            />
          </div>
        </Card>
        <CreateForm {...parentMethods} modalVisible={modalVisible} />
        {stepFormValues && Object.keys(stepFormValues).length ? (
          <UpdateForm
            {...updateMethods}
            updateModalVisible={updateModalVisible}
            values={stepFormValues}
          />
        ) : null}
      </PageHeaderWrapper>
    );
  }
}

export default Form.create<TableListProps>()(TableList);
