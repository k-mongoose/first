export interface TableListItem { //列表标题参数类型
  key: number;
  disabled?: boolean;
  href: string;
  avatar: string;
  name: string;
  title: string;
  owner: string; //创建者
  desc: string;  //工作描述
  callNo: number; 
  status: number; //状态
  createdAt:Date;  //开始时间
  updatedAt:Date; //完成时间
  progress: number; 
}

export interface TableListPagination {//分页查询数据类型
  total: number;
  pageSize: number;
  current: number;
}

export interface TableListData { //列表数据类型
  list: TableListItem[]; //表头
  pagination: Partial<TableListPagination>; //分页
}

export interface TableListParams { //列表标题参数
  sorter: string;
  status: string;
  name: string;
  pageSize: number;
  currentPage: number;
  updatedAt:Date;
  createdAt:Date;
  desc: string;  //工作描述
}
