import { Form, Input, Modal} from 'antd';

import { FormComponentProps } from 'antd/es/form';
import React from 'react';

const FormItem = Form.Item;


interface CreateFormProps extends FormComponentProps {
  modalVisible: boolean;
  handleAdd: (
    fieldsValue: {
      // 列表标题类型定义
      desc: string;
      name:string;
      status: number;
      createdAt:Date;
      updatedAt:Date;
    },
  ) => void;
  handleModalVisible: () => void;
}
const CreateForm: React.FC<CreateFormProps> = props => {
  const { modalVisible, form, handleAdd, handleModalVisible } = props;
  const okHandle = () => {
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      form.resetFields();
      handleAdd(fieldsValue);
    });
  };
  // 新增页面内容
  return (
    <Modal
      destroyOnClose
      title="新增"
      visible={modalVisible}
      onOk={okHandle}
      onCancel={() => handleModalVisible()}
    >
      <FormItem label="姓名">
        {form.getFieldDecorator('name', {
          rules: [{ required: true, message: '请输入姓名！' }],
        })(<Input placeholder="请输入姓名" />)}
      </FormItem>,

      <FormItem  label="工作描述">
        {form.getFieldDecorator('desc', {
          rules: [{ required: true, message: '请输入至少五个字符的描述！', min: 5 }],
        })(<Input placeholder="请输入工作描述" />)}
      </FormItem>,
    </Modal>
  );
};

export default Form.create<CreateFormProps>()(CreateForm);
